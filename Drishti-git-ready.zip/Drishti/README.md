# Drishti — Smart Vision Assistant

Accessible React dashboard with a local FastAPI computer-vision backend and Android camera client source.

## Projects

- **[Frontend](drishti-ai/README.md):** React, Vite, responsive dashboard and landing page.
- **[Backend](drishti-ai-backend/README.md):** FastAPI, YOLOv8n, OpenCV, multilingual Tesseract, SQLite and WebSocket.
- **[Android source](drishti-ai-backend/android/README.md):** CameraX phone camera + native TTS and haptics. Requires Android Studio build and physical-device validation; no APK is included.

Read **[START-HERE.md](START-HERE.md)** for setup and limitations. Install model weights explicitly with `python scripts/download_models.py` from the backend folder. Git source does **not** include weights, installed dependencies, private .env files, runtime databases or APKs.

## Quick start

Backend: Python 3.11, dependencies from `requirements.txt`, official weights, Tesseract executable and eng/hin/mar language packs, then `python scripts/run_server.py`. Copy backend `.env.example` to `.env`, set your own long random API_KEY and trusted CORS origins.

Frontend: Node.js 20.19+; `npm install`, configure `.env` using `.env.example`, then `npm run dev`. Pair or enter your backend API key through Device Management. Android is the camera; no laptop webcam is required.

## Verification and boundaries

Backend tests and frontend integration tests exist in each project's `tests/` directory. Native Android compilation and physical-device testing remain required. No exact depth, real GPS route planning, safe-crossing decisions or universal object detection is implemented. Scene descriptions are detected-object summaries, not a detailed VLM.

Assistive prototype only: never replace a cane, guide dog, mobility training or human assistance. Shared-key development auth is not a public multi-user production security system. Review Ultralytics/model/dependency licensing before distribution.

## Security

Never commit `.env`, API keys, personal camera images or runtime OCR/history data. Configure separate local secrets after cloning. If a development key was previously shared, rotate it before public deployment.
